
BiocGenerics:::testPackage('Maaslin2')

