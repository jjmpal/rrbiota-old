class ppr
{
public:
  ppr (double, double );
  std::string a_tag();
  std::string w_tag();

  double hadj;
  double lineheight;
};
