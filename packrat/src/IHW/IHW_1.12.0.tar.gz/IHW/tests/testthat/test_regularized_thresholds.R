# another simple unit test

# give unregularized thresholds to regularize_thresholds
# then regularization constraint should hold!