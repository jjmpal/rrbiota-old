library("testthat")
library("IHW")

test_check("IHW")
