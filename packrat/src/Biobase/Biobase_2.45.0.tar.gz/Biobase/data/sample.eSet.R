if(interactive())
{
  message("Biobase 'sample.eSet' dataset is defunct. Use 'sample.MultiSet' instead.")
}