"print.Gamex" <-
  function(x,...)
  {
    print(x$coefficients)
    invisible()
  }

