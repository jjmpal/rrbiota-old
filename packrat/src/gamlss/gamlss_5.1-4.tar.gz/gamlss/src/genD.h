//
//  genD.h
//  
//
//  Created by Marco Enea on 02/10/15.
//
//

#ifndef genD_h
#define genD_h

#include <stdio.h>
void genD(int *ncols, int *d);
#endif /* genD_h */
