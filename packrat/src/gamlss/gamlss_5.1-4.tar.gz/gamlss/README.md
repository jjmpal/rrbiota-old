# GAMLSS-original
Those are the function for creating the package gamlss
