sgreedy.cart <- function(formula, data, ntree = 1, bootstrap = "none", ...)
{
  sgreedy(formula, data, ntree = ntree, bootstrap = bootstrap, ...)
}
