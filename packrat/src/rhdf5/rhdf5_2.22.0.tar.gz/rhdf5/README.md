# rhdf5

## Current Status

| Travis        | BioC           | Test Coverage |
| ------------- |-------------| -----|
| [![Build Status](https://travis-ci.org/grimbough/rhdf5.svg?branch=master)](https://travis-ci.org/grimbough/rhdf5) | [![BioC Status](https://bioconductor.org/shields/build/devel/bioc/biomaRt.svg)](http://bioconductor.org/checkResults/devel/bioc-LATEST/biomaRt/) | [![Codecov](http://img.shields.io/codecov/c/github/grimbough/rhdf5.svg)](https://codecov.io/gh/grimbough/rhdf5) |

## Contact

Package Homepage: http://bioconductor.org/packages/devel/bioc/html/rhdf5.html 
Bug Reports: https://support.bioconductor.org/p/new/post/?tag_val=rhdf5.


