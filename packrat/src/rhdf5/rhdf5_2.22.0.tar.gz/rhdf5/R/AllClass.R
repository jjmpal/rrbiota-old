
setClass("H5IdComponent",
         representation(ID = "integer")
)

## setClass("H5attribute",
##          contains = "H5IdComponent"
## )

## setClass("H5DataSpace",
##          contains = "H5IdComponent"
## )

## setClass("H5DataSet",
##          contains = "H5IdComponent"
## )

## setClass("H5DataType",
##          contains = "H5IdComponent"
## )

## setClass("H5DataType",
##          contains = "H5IdComponent"
## )

## setClass("H5file",
##          contains = "H5IdComponent"
## )

## setClass("H5PropList",
##          contains = "H5IdComponent"
## )

## setClass("H5group",
##          contains = "H5IdComponent"
## )

## setClass("H5space",
##          contains = "H5IdComponent"
## )

## setClass("H5dataset",
##          contains = "H5IdComponent"
## )





## setClass("H5Object",
##          contains = "H5IdComponent"
## )

