processFunction = function( frmeData, aiMetadata, aiGenetics, aiData )
{
  return( list(frmeData = frmeData, aiMetadata = aiMetadata, aiData = aiData) )
}
