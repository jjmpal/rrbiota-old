### what is 90% of pi?
almost.pi <- 90/100 * pi

## percents should be escaped neither in inlinedocs, nor in
## Documentation Lists, but will be escaped when written to Rd files.
.result <- list(almost.pi=list(description="what is 90% of pi?",
                definition="almost.pi <- 90/100 * pi",
                format="",
                title="almost pi"))
