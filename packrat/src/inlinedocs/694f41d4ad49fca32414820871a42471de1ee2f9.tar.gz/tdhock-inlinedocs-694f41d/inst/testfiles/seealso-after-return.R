test <- function
### the desc
(x,
### the first argument
 y ##<< another argument
 ){
  5
### the return value
##seealso<< foobar
}

.result <- 
 list(test = list(definition = "test <- function\n### the desc\n(x,\n### the first argument\n y ##<< another argument\n ){\n  5\n### the return value\n##seealso<< foobar\n}",  
     description = "the desc", `item{x}` = "the first argument",  
     value = "the return value", `item{y}` = "another argument",  
     seealso = "foobar", format = "", title = "test")) 
