foo <- function
### This description
###
### should make it into the docs.
(x){
}

.result <-
  list(foo=list(description="This description\n\nshould make it into the docs.",
       definition="foo <- function\n### This description\n###\n### should make it into the docs.\n(x){\n}",
       format="",
       title="foo"))
