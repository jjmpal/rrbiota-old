spaced <- function
### desc
(arg1,
 arg2
 ){
  x <- arg1
  x*2
### some result

}
.result <- 
 list(spaced = list(definition = "spaced <- function\n### desc\n(arg1,\n arg2\n ){\n  x <- arg1\n  x*2\n### some result\n\n}",
     format = "", title = "spaced",value="some result",description="desc"))

