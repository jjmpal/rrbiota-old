"vectorElements<-" <- function(
		### adds or replaces value in vec
		vec			##<< a named vector
		,value		##<< a named vector of same mode as vec
){
}

.result <- 
		list(`vectorElements<-` = list(definition = "\"vectorElements<-\" <- function(\n\t\t### adds or replaces value in vec\n\t\tvec\t\t\t##<< a named vector\n\t\t,value\t\t##<< a named vector of same mode as vec\n){\n}",  
						description = "adds or replaces value in vec", `item{vec}` = "a named vector",  
						`item{value}` = "a named vector of same mode as vec", format = "",  
						title = "vectorElements<-")) 
