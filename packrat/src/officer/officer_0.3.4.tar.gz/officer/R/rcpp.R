#' @useDynLib officer,.registration = TRUE
#' @importFrom Rcpp sourceCpp
NULL
