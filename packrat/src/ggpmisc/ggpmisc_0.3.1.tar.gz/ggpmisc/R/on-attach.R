.onAttach <- function(libname, pkgname) {
  packageStartupMessage("For news about '", pkgname,
                        "', please, see https://www.r4photobiology.info/")
}
