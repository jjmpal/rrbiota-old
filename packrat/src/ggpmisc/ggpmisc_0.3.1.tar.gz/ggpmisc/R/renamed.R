#' Renamed to stat_quadrant_counts
#'
#' Function \code{stat_quadrant_counts()} was initially named
#'   \code{stat_quadrat_counts()} by mistake, and later its name corrected
#'   to \code{stat_quadrant_counts()}.
#'
#' @name stat_quadrat_counts
#'
#' @rdname renamed
#'
NULL
