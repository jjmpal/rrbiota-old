#' @importFrom foreach %dopar%
#' @import Matrix
#' @import doParallel
NULL
